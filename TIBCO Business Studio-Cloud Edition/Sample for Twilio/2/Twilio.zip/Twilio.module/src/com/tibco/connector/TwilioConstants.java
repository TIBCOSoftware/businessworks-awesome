package com.tibco.connector;

public interface TwilioConstants {
String Url="http://demo.twilio.com/welcome/voice/";
	
    String SMS="Hi This is Santosh Bhutkar. I will call you in the Morning";

}
