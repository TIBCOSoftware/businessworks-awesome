package tcizendesk.module.common;

public class TypeConversion {
public static int convert(String value)
{
	return Integer.parseInt(value);
}
public static long convertToLong(String value)
{
	return Long.parseLong(value);
}
}
